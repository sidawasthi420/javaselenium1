package org.openqa.selenium.devtools.latest.console;

import org.openqa.selenium.Beta;
import org.openqa.selenium.devtools.Command;
import org.openqa.selenium.devtools.Event;
import org.openqa.selenium.devtools.ConverterFunctions;
import java.util.Map;
import java.util.LinkedHashMap;
import org.openqa.selenium.json.JsonInput;

/**
 * This domain is deprecated - use Runtime or Log instead.
 */
@Deprecated()
public class Console {

    /**
     * Does nothing.
     */
    public static Command<Void> clearMessages() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Console.clearMessages", Map.copyOf(params));
    }

    /**
     * Disables console domain, prevents further console messages from being reported to the client.
     */
    public static Command<Void> disable() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Console.disable", Map.copyOf(params));
    }

    /**
     * Enables console domain, sends the messages collected so far to the client by means of the
     * `messageAdded` notification.
     */
    public static Command<Void> enable() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Console.enable", Map.copyOf(params));
    }

    public static Event<org.openqa.selenium.devtools.latest.console.model.ConsoleMessage> messageAdded() {
        return new Event<>("Console.messageAdded", ConverterFunctions.map("message", org.openqa.selenium.devtools.latest.console.model.ConsoleMessage.class));
    }
}
