package org.openqa.selenium.devtools.latest.emulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when a page calls screen.orientation.lock() or screen.orientation.unlock()
 * while device emulation is enabled. This allows the DevTools frontend to update the
 * emulated device orientation accordingly.
 */
@org.openqa.selenium.Beta()
public class ScreenOrientationLockChanged {

    private final java.lang.Boolean locked;

    private final java.util.Optional<org.openqa.selenium.devtools.latest.emulation.model.ScreenOrientation> orientation;

    public ScreenOrientationLockChanged(java.lang.Boolean locked, java.util.Optional<org.openqa.selenium.devtools.latest.emulation.model.ScreenOrientation> orientation) {
        this.locked = java.util.Objects.requireNonNull(locked, "locked is required");
        this.orientation = orientation;
    }

    /**
     * Whether the screen orientation is currently locked.
     */
    public java.lang.Boolean getLocked() {
        return locked;
    }

    /**
     * The orientation lock type requested by the page. Only set when locked is true.
     */
    public java.util.Optional<org.openqa.selenium.devtools.latest.emulation.model.ScreenOrientation> getOrientation() {
        return orientation;
    }

    private static ScreenOrientationLockChanged fromJson(JsonInput input) {
        java.lang.Boolean locked = false;
        java.util.Optional<org.openqa.selenium.devtools.latest.emulation.model.ScreenOrientation> orientation = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "locked":
                    locked = input.nextBoolean();
                    break;
                case "orientation":
                    orientation = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.latest.emulation.model.ScreenOrientation.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ScreenOrientationLockChanged(locked, orientation);
    }
}
