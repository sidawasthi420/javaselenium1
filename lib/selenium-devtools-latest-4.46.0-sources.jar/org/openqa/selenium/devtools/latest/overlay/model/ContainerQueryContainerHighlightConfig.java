package org.openqa.selenium.devtools.latest.overlay.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class ContainerQueryContainerHighlightConfig {

    private final java.util.Optional<org.openqa.selenium.devtools.latest.overlay.model.LineStyle> containerBorder;

    private final java.util.Optional<org.openqa.selenium.devtools.latest.overlay.model.LineStyle> descendantBorder;

    public ContainerQueryContainerHighlightConfig(java.util.Optional<org.openqa.selenium.devtools.latest.overlay.model.LineStyle> containerBorder, java.util.Optional<org.openqa.selenium.devtools.latest.overlay.model.LineStyle> descendantBorder) {
        this.containerBorder = containerBorder;
        this.descendantBorder = descendantBorder;
    }

    /**
     * The style of the container border.
     */
    public java.util.Optional<org.openqa.selenium.devtools.latest.overlay.model.LineStyle> getContainerBorder() {
        return containerBorder;
    }

    /**
     * The style of the descendants' borders.
     */
    public java.util.Optional<org.openqa.selenium.devtools.latest.overlay.model.LineStyle> getDescendantBorder() {
        return descendantBorder;
    }

    private static ContainerQueryContainerHighlightConfig fromJson(JsonInput input) {
        java.util.Optional<org.openqa.selenium.devtools.latest.overlay.model.LineStyle> containerBorder = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.latest.overlay.model.LineStyle> descendantBorder = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "containerBorder":
                    containerBorder = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.latest.overlay.model.LineStyle.class));
                    break;
                case "descendantBorder":
                    descendantBorder = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.latest.overlay.model.LineStyle.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ContainerQueryContainerHighlightConfig(containerBorder, descendantBorder);
    }
}
