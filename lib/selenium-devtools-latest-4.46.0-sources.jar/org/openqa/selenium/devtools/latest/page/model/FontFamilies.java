package org.openqa.selenium.devtools.latest.page.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Generic font families collection.
 */
@org.openqa.selenium.Beta()
public class FontFamilies {

    private final java.util.Optional<java.lang.String> standard;

    private final java.util.Optional<java.lang.String> fixed;

    private final java.util.Optional<java.lang.String> serif;

    private final java.util.Optional<java.lang.String> sansSerif;

    private final java.util.Optional<java.lang.String> cursive;

    private final java.util.Optional<java.lang.String> fantasy;

    private final java.util.Optional<java.lang.String> math;

    public FontFamilies(java.util.Optional<java.lang.String> standard, java.util.Optional<java.lang.String> fixed, java.util.Optional<java.lang.String> serif, java.util.Optional<java.lang.String> sansSerif, java.util.Optional<java.lang.String> cursive, java.util.Optional<java.lang.String> fantasy, java.util.Optional<java.lang.String> math) {
        this.standard = standard;
        this.fixed = fixed;
        this.serif = serif;
        this.sansSerif = sansSerif;
        this.cursive = cursive;
        this.fantasy = fantasy;
        this.math = math;
    }

    /**
     * The standard font-family.
     */
    public java.util.Optional<java.lang.String> getStandard() {
        return standard;
    }

    /**
     * The fixed font-family.
     */
    public java.util.Optional<java.lang.String> getFixed() {
        return fixed;
    }

    /**
     * The serif font-family.
     */
    public java.util.Optional<java.lang.String> getSerif() {
        return serif;
    }

    /**
     * The sansSerif font-family.
     */
    public java.util.Optional<java.lang.String> getSansSerif() {
        return sansSerif;
    }

    /**
     * The cursive font-family.
     */
    public java.util.Optional<java.lang.String> getCursive() {
        return cursive;
    }

    /**
     * The fantasy font-family.
     */
    public java.util.Optional<java.lang.String> getFantasy() {
        return fantasy;
    }

    /**
     * The math font-family.
     */
    public java.util.Optional<java.lang.String> getMath() {
        return math;
    }

    private static FontFamilies fromJson(JsonInput input) {
        java.util.Optional<java.lang.String> standard = java.util.Optional.empty();
        java.util.Optional<java.lang.String> fixed = java.util.Optional.empty();
        java.util.Optional<java.lang.String> serif = java.util.Optional.empty();
        java.util.Optional<java.lang.String> sansSerif = java.util.Optional.empty();
        java.util.Optional<java.lang.String> cursive = java.util.Optional.empty();
        java.util.Optional<java.lang.String> fantasy = java.util.Optional.empty();
        java.util.Optional<java.lang.String> math = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "standard":
                    standard = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "fixed":
                    fixed = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "serif":
                    serif = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "sansSerif":
                    sansSerif = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "cursive":
                    cursive = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "fantasy":
                    fantasy = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "math":
                    math = java.util.Optional.ofNullable(input.nextString());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new FontFamilies(standard, fixed, serif, sansSerif, cursive, fantasy, math);
    }
}
