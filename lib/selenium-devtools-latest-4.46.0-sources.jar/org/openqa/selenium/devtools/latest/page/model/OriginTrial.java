package org.openqa.selenium.devtools.latest.page.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class OriginTrial {

    private final java.lang.String trialName;

    private final org.openqa.selenium.devtools.latest.page.model.OriginTrialStatus status;

    private final java.util.List<org.openqa.selenium.devtools.latest.page.model.OriginTrialTokenWithStatus> tokensWithStatus;

    public OriginTrial(java.lang.String trialName, org.openqa.selenium.devtools.latest.page.model.OriginTrialStatus status, java.util.List<org.openqa.selenium.devtools.latest.page.model.OriginTrialTokenWithStatus> tokensWithStatus) {
        this.trialName = java.util.Objects.requireNonNull(trialName, "trialName is required");
        this.status = java.util.Objects.requireNonNull(status, "status is required");
        this.tokensWithStatus = java.util.Objects.requireNonNull(tokensWithStatus, "tokensWithStatus is required");
    }

    public java.lang.String getTrialName() {
        return trialName;
    }

    public org.openqa.selenium.devtools.latest.page.model.OriginTrialStatus getStatus() {
        return status;
    }

    public java.util.List<org.openqa.selenium.devtools.latest.page.model.OriginTrialTokenWithStatus> getTokensWithStatus() {
        return tokensWithStatus;
    }

    private static OriginTrial fromJson(JsonInput input) {
        java.lang.String trialName = null;
        org.openqa.selenium.devtools.latest.page.model.OriginTrialStatus status = null;
        java.util.List<org.openqa.selenium.devtools.latest.page.model.OriginTrialTokenWithStatus> tokensWithStatus = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "trialName":
                    trialName = input.nextString();
                    break;
                case "status":
                    status = input.read(org.openqa.selenium.devtools.latest.page.model.OriginTrialStatus.class);
                    break;
                case "tokensWithStatus":
                    tokensWithStatus = input.readArray(org.openqa.selenium.devtools.latest.page.model.OriginTrialTokenWithStatus.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new OriginTrial(trialName, status, tokensWithStatus);
    }
}
