package org.openqa.selenium.devtools.latest.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when |SCardControl| is called.
 *
 * This maps to:
 * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#gac3454d4657110fd7f753b2d3d8f4e32f
 * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardcontrol
 */
public class ControlRequested {

    private final java.lang.String requestId;

    private final java.lang.Integer handle;

    private final java.lang.Integer controlCode;

    private final java.lang.String data;

    public ControlRequested(java.lang.String requestId, java.lang.Integer handle, java.lang.Integer controlCode, java.lang.String data) {
        this.requestId = java.util.Objects.requireNonNull(requestId, "requestId is required");
        this.handle = java.util.Objects.requireNonNull(handle, "handle is required");
        this.controlCode = java.util.Objects.requireNonNull(controlCode, "controlCode is required");
        this.data = java.util.Objects.requireNonNull(data, "data is required");
    }

    public java.lang.String getRequestId() {
        return requestId;
    }

    public java.lang.Integer getHandle() {
        return handle;
    }

    public java.lang.Integer getControlCode() {
        return controlCode;
    }

    public java.lang.String getData() {
        return data;
    }

    private static ControlRequested fromJson(JsonInput input) {
        java.lang.String requestId = null;
        java.lang.Integer handle = 0;
        java.lang.Integer controlCode = 0;
        java.lang.String data = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "requestId":
                    requestId = input.nextString();
                    break;
                case "handle":
                    handle = input.nextNumber().intValue();
                    break;
                case "controlCode":
                    controlCode = input.nextNumber().intValue();
                    break;
                case "data":
                    data = input.nextString();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ControlRequested(requestId, handle, controlCode, data);
    }
}
