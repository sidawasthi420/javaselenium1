package org.openqa.selenium.devtools.latest.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Maps to the |SCARD_PROTOCOL_*| flags.
 */
public class ProtocolSet {

    private final java.util.Optional<java.lang.Boolean> t0;

    private final java.util.Optional<java.lang.Boolean> t1;

    private final java.util.Optional<java.lang.Boolean> raw;

    public ProtocolSet(java.util.Optional<java.lang.Boolean> t0, java.util.Optional<java.lang.Boolean> t1, java.util.Optional<java.lang.Boolean> raw) {
        this.t0 = t0;
        this.t1 = t1;
        this.raw = raw;
    }

    public java.util.Optional<java.lang.Boolean> getT0() {
        return t0;
    }

    public java.util.Optional<java.lang.Boolean> getT1() {
        return t1;
    }

    public java.util.Optional<java.lang.Boolean> getRaw() {
        return raw;
    }

    private static ProtocolSet fromJson(JsonInput input) {
        java.util.Optional<java.lang.Boolean> t0 = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> t1 = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> raw = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "t0":
                    t0 = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "t1":
                    t1 = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "raw":
                    raw = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ProtocolSet(t0, t1, raw);
    }
}
