package org.openqa.selenium.devtools.latest.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Maps to the |SCARD_STATE_*| flags.
 */
public class ReaderStateFlags {

    private final java.util.Optional<java.lang.Boolean> unaware;

    private final java.util.Optional<java.lang.Boolean> ignore;

    private final java.util.Optional<java.lang.Boolean> changed;

    private final java.util.Optional<java.lang.Boolean> unknown;

    private final java.util.Optional<java.lang.Boolean> unavailable;

    private final java.util.Optional<java.lang.Boolean> empty;

    private final java.util.Optional<java.lang.Boolean> present;

    private final java.util.Optional<java.lang.Boolean> exclusive;

    private final java.util.Optional<java.lang.Boolean> inuse;

    private final java.util.Optional<java.lang.Boolean> mute;

    private final java.util.Optional<java.lang.Boolean> unpowered;

    public ReaderStateFlags(java.util.Optional<java.lang.Boolean> unaware, java.util.Optional<java.lang.Boolean> ignore, java.util.Optional<java.lang.Boolean> changed, java.util.Optional<java.lang.Boolean> unknown, java.util.Optional<java.lang.Boolean> unavailable, java.util.Optional<java.lang.Boolean> empty, java.util.Optional<java.lang.Boolean> present, java.util.Optional<java.lang.Boolean> exclusive, java.util.Optional<java.lang.Boolean> inuse, java.util.Optional<java.lang.Boolean> mute, java.util.Optional<java.lang.Boolean> unpowered) {
        this.unaware = unaware;
        this.ignore = ignore;
        this.changed = changed;
        this.unknown = unknown;
        this.unavailable = unavailable;
        this.empty = empty;
        this.present = present;
        this.exclusive = exclusive;
        this.inuse = inuse;
        this.mute = mute;
        this.unpowered = unpowered;
    }

    public java.util.Optional<java.lang.Boolean> getUnaware() {
        return unaware;
    }

    public java.util.Optional<java.lang.Boolean> getIgnore() {
        return ignore;
    }

    public java.util.Optional<java.lang.Boolean> getChanged() {
        return changed;
    }

    public java.util.Optional<java.lang.Boolean> getUnknown() {
        return unknown;
    }

    public java.util.Optional<java.lang.Boolean> getUnavailable() {
        return unavailable;
    }

    public java.util.Optional<java.lang.Boolean> getEmpty() {
        return empty;
    }

    public java.util.Optional<java.lang.Boolean> getPresent() {
        return present;
    }

    public java.util.Optional<java.lang.Boolean> getExclusive() {
        return exclusive;
    }

    public java.util.Optional<java.lang.Boolean> getInuse() {
        return inuse;
    }

    public java.util.Optional<java.lang.Boolean> getMute() {
        return mute;
    }

    public java.util.Optional<java.lang.Boolean> getUnpowered() {
        return unpowered;
    }

    private static ReaderStateFlags fromJson(JsonInput input) {
        java.util.Optional<java.lang.Boolean> unaware = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> ignore = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> changed = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> unknown = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> unavailable = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> empty = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> present = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> exclusive = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> inuse = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> mute = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> unpowered = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "unaware":
                    unaware = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "ignore":
                    ignore = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "changed":
                    changed = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "unknown":
                    unknown = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "unavailable":
                    unavailable = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "empty":
                    empty = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "present":
                    present = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "exclusive":
                    exclusive = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "inuse":
                    inuse = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "mute":
                    mute = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "unpowered":
                    unpowered = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ReaderStateFlags(unaware, ignore, changed, unknown, unavailable, empty, present, exclusive, inuse, mute, unpowered);
    }
}
