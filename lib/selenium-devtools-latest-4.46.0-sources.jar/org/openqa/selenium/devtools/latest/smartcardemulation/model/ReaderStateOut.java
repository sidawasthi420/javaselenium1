package org.openqa.selenium.devtools.latest.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class ReaderStateOut {

    private final java.lang.String reader;

    private final org.openqa.selenium.devtools.latest.smartcardemulation.model.ReaderStateFlags eventState;

    private final java.lang.Integer eventCount;

    private final java.lang.String atr;

    public ReaderStateOut(java.lang.String reader, org.openqa.selenium.devtools.latest.smartcardemulation.model.ReaderStateFlags eventState, java.lang.Integer eventCount, java.lang.String atr) {
        this.reader = java.util.Objects.requireNonNull(reader, "reader is required");
        this.eventState = java.util.Objects.requireNonNull(eventState, "eventState is required");
        this.eventCount = java.util.Objects.requireNonNull(eventCount, "eventCount is required");
        this.atr = java.util.Objects.requireNonNull(atr, "atr is required");
    }

    public java.lang.String getReader() {
        return reader;
    }

    public org.openqa.selenium.devtools.latest.smartcardemulation.model.ReaderStateFlags getEventState() {
        return eventState;
    }

    public java.lang.Integer getEventCount() {
        return eventCount;
    }

    public java.lang.String getAtr() {
        return atr;
    }

    private static ReaderStateOut fromJson(JsonInput input) {
        java.lang.String reader = null;
        org.openqa.selenium.devtools.latest.smartcardemulation.model.ReaderStateFlags eventState = null;
        java.lang.Integer eventCount = 0;
        java.lang.String atr = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "reader":
                    reader = input.nextString();
                    break;
                case "eventState":
                    eventState = input.read(org.openqa.selenium.devtools.latest.smartcardemulation.model.ReaderStateFlags.class);
                    break;
                case "eventCount":
                    eventCount = input.nextNumber().intValue();
                    break;
                case "atr":
                    atr = input.nextString();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ReaderStateOut(reader, eventState, eventCount, atr);
    }
}
