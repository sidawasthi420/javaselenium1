package org.openqa.selenium.devtools.latest.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when |SCardStatus| is called.
 *
 * This maps to:
 * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#gae49c3c894ad7ac12a5b896bde70d0382
 * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardstatusa
 */
public class StatusRequested {

    private final java.lang.String requestId;

    private final java.lang.Integer handle;

    public StatusRequested(java.lang.String requestId, java.lang.Integer handle) {
        this.requestId = java.util.Objects.requireNonNull(requestId, "requestId is required");
        this.handle = java.util.Objects.requireNonNull(handle, "handle is required");
    }

    public java.lang.String getRequestId() {
        return requestId;
    }

    public java.lang.Integer getHandle() {
        return handle;
    }

    private static StatusRequested fromJson(JsonInput input) {
        java.lang.String requestId = null;
        java.lang.Integer handle = 0;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "requestId":
                    requestId = input.nextString();
                    break;
                case "handle":
                    handle = input.nextNumber().intValue();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new StatusRequested(requestId, handle);
    }
}
