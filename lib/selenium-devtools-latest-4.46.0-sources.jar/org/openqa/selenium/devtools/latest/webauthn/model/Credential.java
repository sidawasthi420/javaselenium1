package org.openqa.selenium.devtools.latest.webauthn.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class Credential {

    private final java.lang.String credentialId;

    private final java.lang.Boolean isResidentCredential;

    private final java.util.Optional<java.lang.String> rpId;

    private final java.lang.String privateKey;

    private final java.util.Optional<java.lang.String> userHandle;

    private final java.lang.Integer signCount;

    private final java.util.Optional<java.lang.String> largeBlob;

    private final java.util.Optional<java.lang.Boolean> backupEligibility;

    private final java.util.Optional<java.lang.Boolean> backupState;

    private final java.util.Optional<java.lang.String> userName;

    private final java.util.Optional<java.lang.String> userDisplayName;

    public Credential(java.lang.String credentialId, java.lang.Boolean isResidentCredential, java.util.Optional<java.lang.String> rpId, java.lang.String privateKey, java.util.Optional<java.lang.String> userHandle, java.lang.Integer signCount, java.util.Optional<java.lang.String> largeBlob, java.util.Optional<java.lang.Boolean> backupEligibility, java.util.Optional<java.lang.Boolean> backupState, java.util.Optional<java.lang.String> userName, java.util.Optional<java.lang.String> userDisplayName) {
        this.credentialId = java.util.Objects.requireNonNull(credentialId, "credentialId is required");
        this.isResidentCredential = java.util.Objects.requireNonNull(isResidentCredential, "isResidentCredential is required");
        this.rpId = rpId;
        this.privateKey = java.util.Objects.requireNonNull(privateKey, "privateKey is required");
        this.userHandle = userHandle;
        this.signCount = java.util.Objects.requireNonNull(signCount, "signCount is required");
        this.largeBlob = largeBlob;
        this.backupEligibility = backupEligibility;
        this.backupState = backupState;
        this.userName = userName;
        this.userDisplayName = userDisplayName;
    }

    public java.lang.String getCredentialId() {
        return credentialId;
    }

    public java.lang.Boolean getIsResidentCredential() {
        return isResidentCredential;
    }

    /**
     * Relying Party ID the credential is scoped to. Must be set when adding a
     * credential.
     */
    public java.util.Optional<java.lang.String> getRpId() {
        return rpId;
    }

    /**
     * The ECDSA P-256 private key in PKCS#8 format.
     */
    public java.lang.String getPrivateKey() {
        return privateKey;
    }

    /**
     * An opaque byte sequence with a maximum size of 64 bytes mapping the
     * credential to a specific user.
     */
    public java.util.Optional<java.lang.String> getUserHandle() {
        return userHandle;
    }

    /**
     * Signature counter. This is incremented by one for each successful
     * assertion.
     * See https://w3c.github.io/webauthn/#signature-counter
     */
    public java.lang.Integer getSignCount() {
        return signCount;
    }

    /**
     * The large blob associated with the credential.
     * See https://w3c.github.io/webauthn/#sctn-large-blob-extension
     */
    public java.util.Optional<java.lang.String> getLargeBlob() {
        return largeBlob;
    }

    /**
     * Assertions returned by this credential will have the backup eligibility
     * (BE) flag set to this value. Defaults to the authenticator's
     * defaultBackupEligibility value.
     */
    public java.util.Optional<java.lang.Boolean> getBackupEligibility() {
        return backupEligibility;
    }

    /**
     * Assertions returned by this credential will have the backup state (BS)
     * flag set to this value. Defaults to the authenticator's
     * defaultBackupState value.
     */
    public java.util.Optional<java.lang.Boolean> getBackupState() {
        return backupState;
    }

    /**
     * The credential's user.name property. Equivalent to empty if not set.
     * https://w3c.github.io/webauthn/#dom-publickeycredentialentity-name
     */
    public java.util.Optional<java.lang.String> getUserName() {
        return userName;
    }

    /**
     * The credential's user.displayName property. Equivalent to empty if
     * not set.
     * https://w3c.github.io/webauthn/#dom-publickeycredentialuserentity-displayname
     */
    public java.util.Optional<java.lang.String> getUserDisplayName() {
        return userDisplayName;
    }

    private static Credential fromJson(JsonInput input) {
        java.lang.String credentialId = null;
        java.lang.Boolean isResidentCredential = false;
        java.util.Optional<java.lang.String> rpId = java.util.Optional.empty();
        java.lang.String privateKey = null;
        java.util.Optional<java.lang.String> userHandle = java.util.Optional.empty();
        java.lang.Integer signCount = 0;
        java.util.Optional<java.lang.String> largeBlob = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> backupEligibility = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> backupState = java.util.Optional.empty();
        java.util.Optional<java.lang.String> userName = java.util.Optional.empty();
        java.util.Optional<java.lang.String> userDisplayName = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "credentialId":
                    credentialId = input.nextString();
                    break;
                case "isResidentCredential":
                    isResidentCredential = input.nextBoolean();
                    break;
                case "rpId":
                    rpId = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "privateKey":
                    privateKey = input.nextString();
                    break;
                case "userHandle":
                    userHandle = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "signCount":
                    signCount = input.nextNumber().intValue();
                    break;
                case "largeBlob":
                    largeBlob = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "backupEligibility":
                    backupEligibility = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "backupState":
                    backupState = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "userName":
                    userName = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "userDisplayName":
                    userDisplayName = java.util.Optional.ofNullable(input.nextString());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new Credential(credentialId, isResidentCredential, rpId, privateKey, userHandle, signCount, largeBlob, backupEligibility, backupState, userName, userDisplayName);
    }
}
