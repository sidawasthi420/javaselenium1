package org.openqa.selenium.devtools.latest.webmcp.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Represents the status of a tool invocation.
 */
public enum InvocationStatus {

    COMPLETED("Completed"), CANCELED("Canceled"), ERROR("Error");

    private String value;

    InvocationStatus(String value) {
        this.value = value;
    }

    public static InvocationStatus fromString(String s) {
        return java.util.Arrays.stream(InvocationStatus.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within InvocationStatus "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static InvocationStatus fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}
