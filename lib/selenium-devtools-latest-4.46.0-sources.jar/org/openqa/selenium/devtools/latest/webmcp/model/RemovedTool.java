package org.openqa.selenium.devtools.latest.webmcp.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Definition of a tool that was removed.
 */
public class RemovedTool {

    private final java.lang.String name;

    private final org.openqa.selenium.devtools.latest.page.model.FrameId frameId;

    public RemovedTool(java.lang.String name, org.openqa.selenium.devtools.latest.page.model.FrameId frameId) {
        this.name = java.util.Objects.requireNonNull(name, "name is required");
        this.frameId = java.util.Objects.requireNonNull(frameId, "frameId is required");
    }

    /**
     * Tool name.
     */
    public java.lang.String getName() {
        return name;
    }

    /**
     * Frame identifier associated with the tool registration.
     */
    public org.openqa.selenium.devtools.latest.page.model.FrameId getFrameId() {
        return frameId;
    }

    private static RemovedTool fromJson(JsonInput input) {
        java.lang.String name = null;
        org.openqa.selenium.devtools.latest.page.model.FrameId frameId = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "name":
                    name = input.nextString();
                    break;
                case "frameId":
                    frameId = input.read(org.openqa.selenium.devtools.latest.page.model.FrameId.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new RemovedTool(name, frameId);
    }
}
