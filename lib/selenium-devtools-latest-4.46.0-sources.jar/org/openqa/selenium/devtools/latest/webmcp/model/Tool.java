package org.openqa.selenium.devtools.latest.webmcp.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Definition of a tool that can be invoked.
 */
public class Tool {

    private final java.lang.String name;

    private final java.lang.String description;

    private final java.util.Optional<java.util.Map<String, Object>> inputSchema;

    private final java.util.Optional<org.openqa.selenium.devtools.latest.webmcp.model.Annotation> annotations;

    private final org.openqa.selenium.devtools.latest.page.model.FrameId frameId;

    private final java.util.Optional<org.openqa.selenium.devtools.latest.dom.model.BackendNodeId> backendNodeId;

    private final java.util.Optional<org.openqa.selenium.devtools.latest.runtime.model.StackTrace> stackTrace;

    public Tool(java.lang.String name, java.lang.String description, java.util.Optional<java.util.Map<String, Object>> inputSchema, java.util.Optional<org.openqa.selenium.devtools.latest.webmcp.model.Annotation> annotations, org.openqa.selenium.devtools.latest.page.model.FrameId frameId, java.util.Optional<org.openqa.selenium.devtools.latest.dom.model.BackendNodeId> backendNodeId, java.util.Optional<org.openqa.selenium.devtools.latest.runtime.model.StackTrace> stackTrace) {
        this.name = java.util.Objects.requireNonNull(name, "name is required");
        this.description = java.util.Objects.requireNonNull(description, "description is required");
        this.inputSchema = inputSchema;
        this.annotations = annotations;
        this.frameId = java.util.Objects.requireNonNull(frameId, "frameId is required");
        this.backendNodeId = backendNodeId;
        this.stackTrace = stackTrace;
    }

    /**
     * Tool name.
     */
    public java.lang.String getName() {
        return name;
    }

    /**
     * Tool description.
     */
    public java.lang.String getDescription() {
        return description;
    }

    /**
     * Schema for the tool's input parameters.
     */
    public java.util.Optional<java.util.Map<String, Object>> getInputSchema() {
        return inputSchema;
    }

    /**
     * Optional annotations for the tool.
     */
    public java.util.Optional<org.openqa.selenium.devtools.latest.webmcp.model.Annotation> getAnnotations() {
        return annotations;
    }

    /**
     * Frame identifier associated with the tool registration.
     */
    public org.openqa.selenium.devtools.latest.page.model.FrameId getFrameId() {
        return frameId;
    }

    /**
     * Optional node ID for declarative tools.
     */
    public java.util.Optional<org.openqa.selenium.devtools.latest.dom.model.BackendNodeId> getBackendNodeId() {
        return backendNodeId;
    }

    /**
     * The stack trace at the time of the registration.
     */
    public java.util.Optional<org.openqa.selenium.devtools.latest.runtime.model.StackTrace> getStackTrace() {
        return stackTrace;
    }

    private static Tool fromJson(JsonInput input) {
        java.lang.String name = null;
        java.lang.String description = null;
        java.util.Optional<java.util.Map<String, Object>> inputSchema = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.latest.webmcp.model.Annotation> annotations = java.util.Optional.empty();
        org.openqa.selenium.devtools.latest.page.model.FrameId frameId = null;
        java.util.Optional<org.openqa.selenium.devtools.latest.dom.model.BackendNodeId> backendNodeId = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.latest.runtime.model.StackTrace> stackTrace = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "name":
                    name = input.nextString();
                    break;
                case "description":
                    description = input.nextString();
                    break;
                case "inputSchema":
                    inputSchema = java.util.Optional.ofNullable((java.util.Map<String, Object>) input.read(java.util.Map.class));
                    break;
                case "annotations":
                    annotations = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.latest.webmcp.model.Annotation.class));
                    break;
                case "frameId":
                    frameId = input.read(org.openqa.selenium.devtools.latest.page.model.FrameId.class);
                    break;
                case "backendNodeId":
                    backendNodeId = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.latest.dom.model.BackendNodeId.class));
                    break;
                case "stackTrace":
                    stackTrace = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.latest.runtime.model.StackTrace.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new Tool(name, description, inputSchema, annotations, frameId, backendNodeId, stackTrace);
    }
}
