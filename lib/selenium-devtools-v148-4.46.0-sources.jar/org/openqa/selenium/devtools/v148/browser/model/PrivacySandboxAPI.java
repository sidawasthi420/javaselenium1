package org.openqa.selenium.devtools.v148.browser.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public enum PrivacySandboxAPI {

    BIDDINGANDAUCTIONSERVICES("BiddingAndAuctionServices"), TRUSTEDKEYVALUE("TrustedKeyValue");

    private String value;

    PrivacySandboxAPI(String value) {
        this.value = value;
    }

    public static PrivacySandboxAPI fromString(String s) {
        return java.util.Arrays.stream(PrivacySandboxAPI.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within PrivacySandboxAPI "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static PrivacySandboxAPI fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}
