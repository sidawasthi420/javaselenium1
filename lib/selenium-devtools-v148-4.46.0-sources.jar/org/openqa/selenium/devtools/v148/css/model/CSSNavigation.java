package org.openqa.selenium.devtools.v148.css.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * CSS Navigation at-rule descriptor.
 */
@org.openqa.selenium.Beta()
public class CSSNavigation {

    private final java.lang.String text;

    private final java.util.Optional<java.lang.Boolean> active;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.css.model.SourceRange> range;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.dom.model.StyleSheetId> styleSheetId;

    public CSSNavigation(java.lang.String text, java.util.Optional<java.lang.Boolean> active, java.util.Optional<org.openqa.selenium.devtools.v148.css.model.SourceRange> range, java.util.Optional<org.openqa.selenium.devtools.v148.dom.model.StyleSheetId> styleSheetId) {
        this.text = java.util.Objects.requireNonNull(text, "text is required");
        this.active = active;
        this.range = range;
        this.styleSheetId = styleSheetId;
    }

    /**
     * Navigation rule text.
     */
    public java.lang.String getText() {
        return text;
    }

    /**
     * Whether the navigation condition is satisfied.
     */
    public java.util.Optional<java.lang.Boolean> getActive() {
        return active;
    }

    /**
     * The associated rule header range in the enclosing stylesheet (if
     * available).
     */
    public java.util.Optional<org.openqa.selenium.devtools.v148.css.model.SourceRange> getRange() {
        return range;
    }

    /**
     * Identifier of the stylesheet containing this object (if exists).
     */
    public java.util.Optional<org.openqa.selenium.devtools.v148.dom.model.StyleSheetId> getStyleSheetId() {
        return styleSheetId;
    }

    private static CSSNavigation fromJson(JsonInput input) {
        java.lang.String text = null;
        java.util.Optional<java.lang.Boolean> active = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.css.model.SourceRange> range = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.dom.model.StyleSheetId> styleSheetId = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "text":
                    text = input.nextString();
                    break;
                case "active":
                    active = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "range":
                    range = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.css.model.SourceRange.class));
                    break;
                case "styleSheetId":
                    styleSheetId = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.dom.model.StyleSheetId.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new CSSNavigation(text, active, range, styleSheetId);
    }
}
