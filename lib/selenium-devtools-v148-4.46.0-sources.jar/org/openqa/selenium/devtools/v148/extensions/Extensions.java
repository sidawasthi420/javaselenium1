package org.openqa.selenium.devtools.v148.extensions;

import org.openqa.selenium.Beta;
import org.openqa.selenium.devtools.Command;
import org.openqa.selenium.devtools.Event;
import org.openqa.selenium.devtools.ConverterFunctions;
import java.util.Map;
import java.util.LinkedHashMap;
import org.openqa.selenium.json.JsonInput;

/**
 * Defines commands and events for browser extensions.
 */
@Beta()
public class Extensions {

    /**
     * Runs an extension default action.
     * Available if the client is connected using the --remote-debugging-pipe
     * flag and the --enable-unsafe-extension-debugging flag is set.
     */
    public static Command<Void> triggerAction(java.lang.String id, java.lang.String targetId) {
        java.util.Objects.requireNonNull(id, "id is required");
        java.util.Objects.requireNonNull(targetId, "targetId is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("id", id);
        params.put("targetId", targetId);
        return new Command<>("Extensions.triggerAction", Map.copyOf(params));
    }

    /**
     * Installs an unpacked extension from the filesystem similar to
     * --load-extension CLI flags. Returns extension ID once the extension
     * has been installed. Available if the client is connected using the
     * --remote-debugging-pipe flag and the --enable-unsafe-extension-debugging
     * flag is set.
     */
    public static Command<java.lang.String> loadUnpacked(java.lang.String path, java.util.Optional<java.lang.Boolean> enableInIncognito) {
        java.util.Objects.requireNonNull(path, "path is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("path", path);
        enableInIncognito.ifPresent(p -> params.put("enableInIncognito", p));
        return new Command<>("Extensions.loadUnpacked", Map.copyOf(params), ConverterFunctions.map("id", java.lang.String.class));
    }

    /**
     * Gets a list of all unpacked extensions.
     * Available if the client is connected using the --remote-debugging-pipe flag
     * and the --enable-unsafe-extension-debugging flag is set.
     */
    public static Command<java.util.List<org.openqa.selenium.devtools.v148.extensions.model.ExtensionInfo>> getExtensions() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Extensions.getExtensions", Map.copyOf(params), ConverterFunctions.map("extensions", input -> input.readArray(org.openqa.selenium.devtools.v148.extensions.model.ExtensionInfo.class)));
    }

    /**
     * Uninstalls an unpacked extension (others not supported) from the profile.
     * Available if the client is connected using the --remote-debugging-pipe flag
     * and the --enable-unsafe-extension-debugging.
     */
    public static Command<Void> uninstall(java.lang.String id) {
        java.util.Objects.requireNonNull(id, "id is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("id", id);
        return new Command<>("Extensions.uninstall", Map.copyOf(params));
    }

    /**
     * Gets data from extension storage in the given `storageArea`. If `keys` is
     * specified, these are used to filter the result.
     */
    public static Command<java.util.Map<String, Object>> getStorageItems(java.lang.String id, org.openqa.selenium.devtools.v148.extensions.model.StorageArea storageArea, java.util.Optional<java.util.List<java.lang.String>> keys) {
        java.util.Objects.requireNonNull(id, "id is required");
        java.util.Objects.requireNonNull(storageArea, "storageArea is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("id", id);
        params.put("storageArea", storageArea);
        keys.ifPresent(p -> params.put("keys", p));
        return new Command<>("Extensions.getStorageItems", Map.copyOf(params), ConverterFunctions.map("data", java.util.Map.class));
    }

    /**
     * Removes `keys` from extension storage in the given `storageArea`.
     */
    public static Command<Void> removeStorageItems(java.lang.String id, org.openqa.selenium.devtools.v148.extensions.model.StorageArea storageArea, java.util.List<java.lang.String> keys) {
        java.util.Objects.requireNonNull(id, "id is required");
        java.util.Objects.requireNonNull(storageArea, "storageArea is required");
        java.util.Objects.requireNonNull(keys, "keys is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("id", id);
        params.put("storageArea", storageArea);
        params.put("keys", keys);
        return new Command<>("Extensions.removeStorageItems", Map.copyOf(params));
    }

    /**
     * Clears extension storage in the given `storageArea`.
     */
    public static Command<Void> clearStorageItems(java.lang.String id, org.openqa.selenium.devtools.v148.extensions.model.StorageArea storageArea) {
        java.util.Objects.requireNonNull(id, "id is required");
        java.util.Objects.requireNonNull(storageArea, "storageArea is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("id", id);
        params.put("storageArea", storageArea);
        return new Command<>("Extensions.clearStorageItems", Map.copyOf(params));
    }

    /**
     * Sets `values` in extension storage in the given `storageArea`. The provided `values`
     * will be merged with existing values in the storage area.
     */
    public static Command<Void> setStorageItems(java.lang.String id, org.openqa.selenium.devtools.v148.extensions.model.StorageArea storageArea, java.util.Map<String, Object> values) {
        java.util.Objects.requireNonNull(id, "id is required");
        java.util.Objects.requireNonNull(storageArea, "storageArea is required");
        java.util.Objects.requireNonNull(values, "values is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("id", id);
        params.put("storageArea", storageArea);
        params.put("values", values);
        return new Command<>("Extensions.setStorageItems", Map.copyOf(params));
    }
}
