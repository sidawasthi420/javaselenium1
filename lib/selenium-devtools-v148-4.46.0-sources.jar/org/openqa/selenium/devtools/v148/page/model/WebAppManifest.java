package org.openqa.selenium.devtools.v148.page.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class WebAppManifest {

    private final java.util.Optional<java.lang.String> backgroundColor;

    private final java.util.Optional<java.lang.String> description;

    private final java.util.Optional<java.lang.String> dir;

    private final java.util.Optional<java.lang.String> display;

    private final java.util.Optional<java.util.List<java.lang.String>> displayOverrides;

    private final java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.FileHandler>> fileHandlers;

    private final java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.ImageResource>> icons;

    private final java.util.Optional<java.lang.String> id;

    private final java.util.Optional<java.lang.String> lang;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.page.model.LaunchHandler> launchHandler;

    private final java.util.Optional<java.lang.String> name;

    private final java.util.Optional<java.lang.String> orientation;

    private final java.util.Optional<java.lang.Boolean> preferRelatedApplications;

    private final java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.ProtocolHandler>> protocolHandlers;

    private final java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.RelatedApplication>> relatedApplications;

    private final java.util.Optional<java.lang.String> scope;

    private final java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.ScopeExtension>> scopeExtensions;

    private final java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.Screenshot>> screenshots;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.page.model.ShareTarget> shareTarget;

    private final java.util.Optional<java.lang.String> shortName;

    private final java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.Shortcut>> shortcuts;

    private final java.util.Optional<java.lang.String> startUrl;

    private final java.util.Optional<java.lang.String> themeColor;

    public WebAppManifest(java.util.Optional<java.lang.String> backgroundColor, java.util.Optional<java.lang.String> description, java.util.Optional<java.lang.String> dir, java.util.Optional<java.lang.String> display, java.util.Optional<java.util.List<java.lang.String>> displayOverrides, java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.FileHandler>> fileHandlers, java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.ImageResource>> icons, java.util.Optional<java.lang.String> id, java.util.Optional<java.lang.String> lang, java.util.Optional<org.openqa.selenium.devtools.v148.page.model.LaunchHandler> launchHandler, java.util.Optional<java.lang.String> name, java.util.Optional<java.lang.String> orientation, java.util.Optional<java.lang.Boolean> preferRelatedApplications, java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.ProtocolHandler>> protocolHandlers, java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.RelatedApplication>> relatedApplications, java.util.Optional<java.lang.String> scope, java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.ScopeExtension>> scopeExtensions, java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.Screenshot>> screenshots, java.util.Optional<org.openqa.selenium.devtools.v148.page.model.ShareTarget> shareTarget, java.util.Optional<java.lang.String> shortName, java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.Shortcut>> shortcuts, java.util.Optional<java.lang.String> startUrl, java.util.Optional<java.lang.String> themeColor) {
        this.backgroundColor = backgroundColor;
        this.description = description;
        this.dir = dir;
        this.display = display;
        this.displayOverrides = displayOverrides;
        this.fileHandlers = fileHandlers;
        this.icons = icons;
        this.id = id;
        this.lang = lang;
        this.launchHandler = launchHandler;
        this.name = name;
        this.orientation = orientation;
        this.preferRelatedApplications = preferRelatedApplications;
        this.protocolHandlers = protocolHandlers;
        this.relatedApplications = relatedApplications;
        this.scope = scope;
        this.scopeExtensions = scopeExtensions;
        this.screenshots = screenshots;
        this.shareTarget = shareTarget;
        this.shortName = shortName;
        this.shortcuts = shortcuts;
        this.startUrl = startUrl;
        this.themeColor = themeColor;
    }

    public java.util.Optional<java.lang.String> getBackgroundColor() {
        return backgroundColor;
    }

    /**
     * The extra description provided by the manifest.
     */
    public java.util.Optional<java.lang.String> getDescription() {
        return description;
    }

    public java.util.Optional<java.lang.String> getDir() {
        return dir;
    }

    public java.util.Optional<java.lang.String> getDisplay() {
        return display;
    }

    /**
     * The overrided display mode controlled by the user.
     */
    public java.util.Optional<java.util.List<java.lang.String>> getDisplayOverrides() {
        return displayOverrides;
    }

    /**
     * The handlers to open files.
     */
    public java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.FileHandler>> getFileHandlers() {
        return fileHandlers;
    }

    public java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.ImageResource>> getIcons() {
        return icons;
    }

    public java.util.Optional<java.lang.String> getId() {
        return id;
    }

    public java.util.Optional<java.lang.String> getLang() {
        return lang;
    }

    /**
     * TODO(crbug.com/1231886): This field is non-standard and part of a Chrome
     * experiment. See:
     * https://github.com/WICG/web-app-launch/blob/main/launch_handler.md
     */
    public java.util.Optional<org.openqa.selenium.devtools.v148.page.model.LaunchHandler> getLaunchHandler() {
        return launchHandler;
    }

    public java.util.Optional<java.lang.String> getName() {
        return name;
    }

    public java.util.Optional<java.lang.String> getOrientation() {
        return orientation;
    }

    public java.util.Optional<java.lang.Boolean> getPreferRelatedApplications() {
        return preferRelatedApplications;
    }

    /**
     * The handlers to open protocols.
     */
    public java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.ProtocolHandler>> getProtocolHandlers() {
        return protocolHandlers;
    }

    public java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.RelatedApplication>> getRelatedApplications() {
        return relatedApplications;
    }

    public java.util.Optional<java.lang.String> getScope() {
        return scope;
    }

    /**
     * Non-standard, see
     * https://github.com/WICG/manifest-incubations/blob/gh-pages/scope_extensions-explainer.md
     */
    public java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.ScopeExtension>> getScopeExtensions() {
        return scopeExtensions;
    }

    /**
     * The screenshots used by chromium.
     */
    public java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.Screenshot>> getScreenshots() {
        return screenshots;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.page.model.ShareTarget> getShareTarget() {
        return shareTarget;
    }

    public java.util.Optional<java.lang.String> getShortName() {
        return shortName;
    }

    public java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.Shortcut>> getShortcuts() {
        return shortcuts;
    }

    public java.util.Optional<java.lang.String> getStartUrl() {
        return startUrl;
    }

    public java.util.Optional<java.lang.String> getThemeColor() {
        return themeColor;
    }

    private static WebAppManifest fromJson(JsonInput input) {
        java.util.Optional<java.lang.String> backgroundColor = java.util.Optional.empty();
        java.util.Optional<java.lang.String> description = java.util.Optional.empty();
        java.util.Optional<java.lang.String> dir = java.util.Optional.empty();
        java.util.Optional<java.lang.String> display = java.util.Optional.empty();
        java.util.Optional<java.util.List<java.lang.String>> displayOverrides = java.util.Optional.empty();
        java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.FileHandler>> fileHandlers = java.util.Optional.empty();
        java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.ImageResource>> icons = java.util.Optional.empty();
        java.util.Optional<java.lang.String> id = java.util.Optional.empty();
        java.util.Optional<java.lang.String> lang = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.page.model.LaunchHandler> launchHandler = java.util.Optional.empty();
        java.util.Optional<java.lang.String> name = java.util.Optional.empty();
        java.util.Optional<java.lang.String> orientation = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> preferRelatedApplications = java.util.Optional.empty();
        java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.ProtocolHandler>> protocolHandlers = java.util.Optional.empty();
        java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.RelatedApplication>> relatedApplications = java.util.Optional.empty();
        java.util.Optional<java.lang.String> scope = java.util.Optional.empty();
        java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.ScopeExtension>> scopeExtensions = java.util.Optional.empty();
        java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.Screenshot>> screenshots = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.page.model.ShareTarget> shareTarget = java.util.Optional.empty();
        java.util.Optional<java.lang.String> shortName = java.util.Optional.empty();
        java.util.Optional<java.util.List<org.openqa.selenium.devtools.v148.page.model.Shortcut>> shortcuts = java.util.Optional.empty();
        java.util.Optional<java.lang.String> startUrl = java.util.Optional.empty();
        java.util.Optional<java.lang.String> themeColor = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "backgroundColor":
                    backgroundColor = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "description":
                    description = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "dir":
                    dir = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "display":
                    display = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "displayOverrides":
                    displayOverrides = java.util.Optional.ofNullable(input.readArray(java.lang.String.class));
                    break;
                case "fileHandlers":
                    fileHandlers = java.util.Optional.ofNullable(input.readArray(org.openqa.selenium.devtools.v148.page.model.FileHandler.class));
                    break;
                case "icons":
                    icons = java.util.Optional.ofNullable(input.readArray(org.openqa.selenium.devtools.v148.page.model.ImageResource.class));
                    break;
                case "id":
                    id = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "lang":
                    lang = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "launchHandler":
                    launchHandler = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.page.model.LaunchHandler.class));
                    break;
                case "name":
                    name = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "orientation":
                    orientation = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "preferRelatedApplications":
                    preferRelatedApplications = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "protocolHandlers":
                    protocolHandlers = java.util.Optional.ofNullable(input.readArray(org.openqa.selenium.devtools.v148.page.model.ProtocolHandler.class));
                    break;
                case "relatedApplications":
                    relatedApplications = java.util.Optional.ofNullable(input.readArray(org.openqa.selenium.devtools.v148.page.model.RelatedApplication.class));
                    break;
                case "scope":
                    scope = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "scopeExtensions":
                    scopeExtensions = java.util.Optional.ofNullable(input.readArray(org.openqa.selenium.devtools.v148.page.model.ScopeExtension.class));
                    break;
                case "screenshots":
                    screenshots = java.util.Optional.ofNullable(input.readArray(org.openqa.selenium.devtools.v148.page.model.Screenshot.class));
                    break;
                case "shareTarget":
                    shareTarget = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.page.model.ShareTarget.class));
                    break;
                case "shortName":
                    shortName = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "shortcuts":
                    shortcuts = java.util.Optional.ofNullable(input.readArray(org.openqa.selenium.devtools.v148.page.model.Shortcut.class));
                    break;
                case "startUrl":
                    startUrl = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "themeColor":
                    themeColor = java.util.Optional.ofNullable(input.nextString());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new WebAppManifest(backgroundColor, description, dir, display, displayOverrides, fileHandlers, icons, id, lang, launchHandler, name, orientation, preferRelatedApplications, protocolHandlers, relatedApplications, scope, scopeExtensions, screenshots, shareTarget, shortName, shortcuts, startUrl, themeColor);
    }
}
