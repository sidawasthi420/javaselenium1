package org.openqa.selenium.devtools.v148.schema;

import org.openqa.selenium.Beta;
import org.openqa.selenium.devtools.Command;
import org.openqa.selenium.devtools.Event;
import org.openqa.selenium.devtools.ConverterFunctions;
import java.util.Map;
import java.util.LinkedHashMap;
import org.openqa.selenium.json.JsonInput;

/**
 * This domain is deprecated.
 */
@Deprecated()
public class Schema {

    /**
     * Returns supported domains.
     */
    public static Command<java.util.List<org.openqa.selenium.devtools.v148.schema.model.Domain>> getDomains() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Schema.getDomains", Map.copyOf(params), ConverterFunctions.map("domains", input -> input.readArray(org.openqa.selenium.devtools.v148.schema.model.Domain.class)));
    }
}
