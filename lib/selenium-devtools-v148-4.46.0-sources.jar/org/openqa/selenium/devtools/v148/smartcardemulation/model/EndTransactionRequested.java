package org.openqa.selenium.devtools.v148.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when |SCardEndTransaction| is called.
 *
 * This maps to:
 * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#gae8742473b404363e5c587f570d7e2f3b
 * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardendtransaction
 */
public class EndTransactionRequested {

    private final java.lang.String requestId;

    private final java.lang.Integer handle;

    private final org.openqa.selenium.devtools.v148.smartcardemulation.model.Disposition disposition;

    public EndTransactionRequested(java.lang.String requestId, java.lang.Integer handle, org.openqa.selenium.devtools.v148.smartcardemulation.model.Disposition disposition) {
        this.requestId = java.util.Objects.requireNonNull(requestId, "requestId is required");
        this.handle = java.util.Objects.requireNonNull(handle, "handle is required");
        this.disposition = java.util.Objects.requireNonNull(disposition, "disposition is required");
    }

    public java.lang.String getRequestId() {
        return requestId;
    }

    public java.lang.Integer getHandle() {
        return handle;
    }

    public org.openqa.selenium.devtools.v148.smartcardemulation.model.Disposition getDisposition() {
        return disposition;
    }

    private static EndTransactionRequested fromJson(JsonInput input) {
        java.lang.String requestId = null;
        java.lang.Integer handle = 0;
        org.openqa.selenium.devtools.v148.smartcardemulation.model.Disposition disposition = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "requestId":
                    requestId = input.nextString();
                    break;
                case "handle":
                    handle = input.nextNumber().intValue();
                    break;
                case "disposition":
                    disposition = input.read(org.openqa.selenium.devtools.v148.smartcardemulation.model.Disposition.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new EndTransactionRequested(requestId, handle, disposition);
    }
}
