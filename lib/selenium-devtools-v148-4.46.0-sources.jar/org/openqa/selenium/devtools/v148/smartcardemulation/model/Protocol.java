package org.openqa.selenium.devtools.v148.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Maps to the |SCARD_PROTOCOL_*| values.
 */
public enum Protocol {

    T0("t0"), T1("t1"), RAW("raw");

    private String value;

    Protocol(String value) {
        this.value = value;
    }

    public static Protocol fromString(String s) {
        return java.util.Arrays.stream(Protocol.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within Protocol "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static Protocol fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}
