package org.openqa.selenium.devtools.v149.accessibility.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * A node in the accessibility tree.
 */
public class AXNode {

    private final org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId nodeId;

    private final java.lang.Boolean ignored;

    private final java.util.Optional<java.util.List<org.openqa.selenium.devtools.v149.accessibility.model.AXProperty>> ignoredReasons;

    private final java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> role;

    private final java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> chromeRole;

    private final java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> name;

    private final java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> description;

    private final java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> value;

    private final java.util.Optional<java.util.List<org.openqa.selenium.devtools.v149.accessibility.model.AXProperty>> properties;

    private final java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId> parentId;

    private final java.util.Optional<java.util.List<org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId>> childIds;

    private final java.util.Optional<org.openqa.selenium.devtools.v149.dom.model.BackendNodeId> backendDOMNodeId;

    private final java.util.Optional<org.openqa.selenium.devtools.v149.page.model.FrameId> frameId;

    public AXNode(org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId nodeId, java.lang.Boolean ignored, java.util.Optional<java.util.List<org.openqa.selenium.devtools.v149.accessibility.model.AXProperty>> ignoredReasons, java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> role, java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> chromeRole, java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> name, java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> description, java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> value, java.util.Optional<java.util.List<org.openqa.selenium.devtools.v149.accessibility.model.AXProperty>> properties, java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId> parentId, java.util.Optional<java.util.List<org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId>> childIds, java.util.Optional<org.openqa.selenium.devtools.v149.dom.model.BackendNodeId> backendDOMNodeId, java.util.Optional<org.openqa.selenium.devtools.v149.page.model.FrameId> frameId) {
        this.nodeId = java.util.Objects.requireNonNull(nodeId, "nodeId is required");
        this.ignored = java.util.Objects.requireNonNull(ignored, "ignored is required");
        this.ignoredReasons = ignoredReasons;
        this.role = role;
        this.chromeRole = chromeRole;
        this.name = name;
        this.description = description;
        this.value = value;
        this.properties = properties;
        this.parentId = parentId;
        this.childIds = childIds;
        this.backendDOMNodeId = backendDOMNodeId;
        this.frameId = frameId;
    }

    /**
     * Unique identifier for this node.
     */
    public org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId getNodeId() {
        return nodeId;
    }

    /**
     * Whether this node is ignored for accessibility
     */
    public java.lang.Boolean getIgnored() {
        return ignored;
    }

    /**
     * Collection of reasons why this node is hidden.
     */
    public java.util.Optional<java.util.List<org.openqa.selenium.devtools.v149.accessibility.model.AXProperty>> getIgnoredReasons() {
        return ignoredReasons;
    }

    /**
     * This `Node`'s role, whether explicit or implicit.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> getRole() {
        return role;
    }

    /**
     * This `Node`'s Chrome raw role.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> getChromeRole() {
        return chromeRole;
    }

    /**
     * The accessible name for this `Node`.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> getName() {
        return name;
    }

    /**
     * The accessible description for this `Node`.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> getDescription() {
        return description;
    }

    /**
     * The value for this `Node`.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> getValue() {
        return value;
    }

    /**
     * All other properties
     */
    public java.util.Optional<java.util.List<org.openqa.selenium.devtools.v149.accessibility.model.AXProperty>> getProperties() {
        return properties;
    }

    /**
     * ID for this node's parent.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId> getParentId() {
        return parentId;
    }

    /**
     * IDs for each of this node's child nodes.
     */
    public java.util.Optional<java.util.List<org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId>> getChildIds() {
        return childIds;
    }

    /**
     * The backend ID for the associated DOM node, if any.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v149.dom.model.BackendNodeId> getBackendDOMNodeId() {
        return backendDOMNodeId;
    }

    /**
     * The frame ID for the frame associated with this nodes document.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v149.page.model.FrameId> getFrameId() {
        return frameId;
    }

    private static AXNode fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId nodeId = null;
        java.lang.Boolean ignored = false;
        java.util.Optional<java.util.List<org.openqa.selenium.devtools.v149.accessibility.model.AXProperty>> ignoredReasons = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> role = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> chromeRole = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> name = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> description = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXValue> value = java.util.Optional.empty();
        java.util.Optional<java.util.List<org.openqa.selenium.devtools.v149.accessibility.model.AXProperty>> properties = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId> parentId = java.util.Optional.empty();
        java.util.Optional<java.util.List<org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId>> childIds = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v149.dom.model.BackendNodeId> backendDOMNodeId = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v149.page.model.FrameId> frameId = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "nodeId":
                    nodeId = input.read(org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId.class);
                    break;
                case "ignored":
                    ignored = input.nextBoolean();
                    break;
                case "ignoredReasons":
                    ignoredReasons = java.util.Optional.ofNullable(input.readArray(org.openqa.selenium.devtools.v149.accessibility.model.AXProperty.class));
                    break;
                case "role":
                    role = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.accessibility.model.AXValue.class));
                    break;
                case "chromeRole":
                    chromeRole = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.accessibility.model.AXValue.class));
                    break;
                case "name":
                    name = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.accessibility.model.AXValue.class));
                    break;
                case "description":
                    description = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.accessibility.model.AXValue.class));
                    break;
                case "value":
                    value = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.accessibility.model.AXValue.class));
                    break;
                case "properties":
                    properties = java.util.Optional.ofNullable(input.readArray(org.openqa.selenium.devtools.v149.accessibility.model.AXProperty.class));
                    break;
                case "parentId":
                    parentId = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId.class));
                    break;
                case "childIds":
                    childIds = java.util.Optional.ofNullable(input.readArray(org.openqa.selenium.devtools.v149.accessibility.model.AXNodeId.class));
                    break;
                case "backendDOMNodeId":
                    backendDOMNodeId = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.dom.model.BackendNodeId.class));
                    break;
                case "frameId":
                    frameId = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.page.model.FrameId.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AXNode(nodeId, ignored, ignoredReasons, role, chromeRole, name, description, value, properties, parentId, childIds, backendDOMNodeId, frameId);
    }
}
