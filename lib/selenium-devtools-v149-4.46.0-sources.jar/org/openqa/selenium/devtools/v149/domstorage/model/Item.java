package org.openqa.selenium.devtools.v149.domstorage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * DOM Storage item.
 */
public class Item {

    private final java.util.List<java.lang.String> item;

    public Item(java.util.List<java.lang.String> item) {
        this.item = java.util.Objects.requireNonNull(item, "Missing value for Item");
    }

    private static Item fromJson(JsonInput input) {
        return new Item(input.readArray(java.lang.String.class));
    }

    public java.util.List<java.lang.String> getItem() {
        return item;
    }

    public String toString() {
        return item.toString();
    }
}
