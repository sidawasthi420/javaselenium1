package org.openqa.selenium.devtools.v149.overlay.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class InspectedElementAnchorConfig {

    private final java.util.Optional<org.openqa.selenium.devtools.v149.dom.model.NodeId> nodeId;

    private final java.util.Optional<org.openqa.selenium.devtools.v149.dom.model.BackendNodeId> backendNodeId;

    public InspectedElementAnchorConfig(java.util.Optional<org.openqa.selenium.devtools.v149.dom.model.NodeId> nodeId, java.util.Optional<org.openqa.selenium.devtools.v149.dom.model.BackendNodeId> backendNodeId) {
        this.nodeId = nodeId;
        this.backendNodeId = backendNodeId;
    }

    /**
     * Identifier of the node to highlight.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v149.dom.model.NodeId> getNodeId() {
        return nodeId;
    }

    /**
     * Identifier of the backend node to highlight.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v149.dom.model.BackendNodeId> getBackendNodeId() {
        return backendNodeId;
    }

    private static InspectedElementAnchorConfig fromJson(JsonInput input) {
        java.util.Optional<org.openqa.selenium.devtools.v149.dom.model.NodeId> nodeId = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v149.dom.model.BackendNodeId> backendNodeId = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "nodeId":
                    nodeId = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.dom.model.NodeId.class));
                    break;
                case "backendNodeId":
                    backendNodeId = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.dom.model.BackendNodeId.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new InspectedElementAnchorConfig(nodeId, backendNodeId);
    }
}
