package org.openqa.selenium.devtools.v149.page.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class FileFilter {

    private final java.util.Optional<java.lang.String> name;

    private final java.util.Optional<java.util.List<java.lang.String>> accepts;

    public FileFilter(java.util.Optional<java.lang.String> name, java.util.Optional<java.util.List<java.lang.String>> accepts) {
        this.name = name;
        this.accepts = accepts;
    }

    public java.util.Optional<java.lang.String> getName() {
        return name;
    }

    public java.util.Optional<java.util.List<java.lang.String>> getAccepts() {
        return accepts;
    }

    private static FileFilter fromJson(JsonInput input) {
        java.util.Optional<java.lang.String> name = java.util.Optional.empty();
        java.util.Optional<java.util.List<java.lang.String>> accepts = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "name":
                    name = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "accepts":
                    accepts = java.util.Optional.ofNullable(input.readArray(java.lang.String.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new FileFilter(name, accepts);
    }
}
