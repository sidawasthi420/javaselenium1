package org.openqa.selenium.devtools.v149.page.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * All Permissions Policy features. This enum should match the one defined
 * in services/network/public/cpp/permissions_policy/permissions_policy_features.json5.
 * LINT.IfChange(PermissionsPolicyFeature)
 */
@org.openqa.selenium.Beta()
public enum PermissionsPolicyFeature {

    ACCELEROMETER("accelerometer"),
    ALL_SCREENS_CAPTURE("all-screens-capture"),
    AMBIENT_LIGHT_SENSOR("ambient-light-sensor"),
    ARIA_NOTIFY("aria-notify"),
    ATTRIBUTION_REPORTING("attribution-reporting"),
    AUTOFILL("autofill"),
    AUTOPLAY("autoplay"),
    BLUETOOTH("bluetooth"),
    BROWSING_TOPICS("browsing-topics"),
    CAMERA("camera"),
    CAPTURED_SURFACE_CONTROL("captured-surface-control"),
    CH_DPR("ch-dpr"),
    CH_DEVICE_MEMORY("ch-device-memory"),
    CH_DOWNLINK("ch-downlink"),
    CH_ECT("ch-ect"),
    CH_PREFERS_COLOR_SCHEME("ch-prefers-color-scheme"),
    CH_PREFERS_REDUCED_MOTION("ch-prefers-reduced-motion"),
    CH_PREFERS_REDUCED_TRANSPARENCY("ch-prefers-reduced-transparency"),
    CH_RTT("ch-rtt"),
    CH_SAVE_DATA("ch-save-data"),
    CH_UA("ch-ua"),
    CH_UA_ARCH("ch-ua-arch"),
    CH_UA_BITNESS("ch-ua-bitness"),
    CH_UA_HIGH_ENTROPY_VALUES("ch-ua-high-entropy-values"),
    CH_UA_PLATFORM("ch-ua-platform"),
    CH_UA_MODEL("ch-ua-model"),
    CH_UA_MOBILE("ch-ua-mobile"),
    CH_UA_FORM_FACTORS("ch-ua-form-factors"),
    CH_UA_FULL_VERSION("ch-ua-full-version"),
    CH_UA_FULL_VERSION_LIST("ch-ua-full-version-list"),
    CH_UA_PLATFORM_VERSION("ch-ua-platform-version"),
    CH_UA_WOW64("ch-ua-wow64"),
    CH_VIEWPORT_HEIGHT("ch-viewport-height"),
    CH_VIEWPORT_WIDTH("ch-viewport-width"),
    CH_WIDTH("ch-width"),
    CLIPBOARD_READ("clipboard-read"),
    CLIPBOARD_WRITE("clipboard-write"),
    COMPUTE_PRESSURE("compute-pressure"),
    CONTROLLED_FRAME("controlled-frame"),
    CROSS_ORIGIN_ISOLATED("cross-origin-isolated"),
    DEFERRED_FETCH("deferred-fetch"),
    DEFERRED_FETCH_MINIMAL("deferred-fetch-minimal"),
    DEVICE_ATTRIBUTES("device-attributes"),
    DIGITAL_CREDENTIALS_CREATE("digital-credentials-create"),
    DIGITAL_CREDENTIALS_GET("digital-credentials-get"),
    DIRECT_SOCKETS("direct-sockets"),
    DIRECT_SOCKETS_MULTICAST("direct-sockets-multicast"),
    DIRECT_SOCKETS_PRIVATE("direct-sockets-private"),
    DISPLAY_CAPTURE("display-capture"),
    DOCUMENT_DOMAIN("document-domain"),
    ENCRYPTED_MEDIA("encrypted-media"),
    EXECUTION_WHILE_OUT_OF_VIEWPORT("execution-while-out-of-viewport"),
    EXECUTION_WHILE_NOT_RENDERED("execution-while-not-rendered"),
    FOCUS_WITHOUT_USER_ACTIVATION("focus-without-user-activation"),
    FULLSCREEN("fullscreen"),
    FROBULATE("frobulate"),
    GAMEPAD("gamepad"),
    GEOLOCATION("geolocation"),
    GYROSCOPE("gyroscope"),
    HID("hid"),
    IDENTITY_CREDENTIALS_GET("identity-credentials-get"),
    IDLE_DETECTION("idle-detection"),
    INTEREST_COHORT("interest-cohort"),
    JOIN_AD_INTEREST_GROUP("join-ad-interest-group"),
    KEYBOARD_MAP("keyboard-map"),
    LANGUAGE_DETECTOR("language-detector"),
    LANGUAGE_MODEL("language-model"),
    LOCAL_FONTS("local-fonts"),
    LOCAL_NETWORK("local-network"),
    LOCAL_NETWORK_ACCESS("local-network-access"),
    LOOPBACK_NETWORK("loopback-network"),
    MAGNETOMETER("magnetometer"),
    MANUAL_TEXT("manual-text"),
    MEDIA_PLAYBACK_WHILE_NOT_VISIBLE("media-playback-while-not-visible"),
    MICROPHONE("microphone"),
    MIDI("midi"),
    ON_DEVICE_SPEECH_RECOGNITION("on-device-speech-recognition"),
    OTP_CREDENTIALS("otp-credentials"),
    PAYMENT("payment"),
    PICTURE_IN_PICTURE("picture-in-picture"),
    PRIVATE_AGGREGATION("private-aggregation"),
    PRIVATE_STATE_TOKEN_ISSUANCE("private-state-token-issuance"),
    PRIVATE_STATE_TOKEN_REDEMPTION("private-state-token-redemption"),
    PUBLICKEY_CREDENTIALS_CREATE("publickey-credentials-create"),
    PUBLICKEY_CREDENTIALS_GET("publickey-credentials-get"),
    RECORD_AD_AUCTION_EVENTS("record-ad-auction-events"),
    REWRITER("rewriter"),
    RUN_AD_AUCTION("run-ad-auction"),
    SCREEN_WAKE_LOCK("screen-wake-lock"),
    SERIAL("serial"),
    SHARED_STORAGE("shared-storage"),
    SHARED_STORAGE_SELECT_URL("shared-storage-select-url"),
    SMART_CARD("smart-card"),
    SPEAKER_SELECTION("speaker-selection"),
    STORAGE_ACCESS("storage-access"),
    SUB_APPS("sub-apps"),
    SUMMARIZER("summarizer"),
    SYNC_XHR("sync-xhr"),
    TOOLS("tools"),
    TRANSLATOR("translator"),
    UNLOAD("unload"),
    USB("usb"),
    USB_UNRESTRICTED("usb-unrestricted"),
    VERTICAL_SCROLL("vertical-scroll"),
    WEB_APP_INSTALLATION("web-app-installation"),
    WEB_PRINTING("web-printing"),
    WEB_SHARE("web-share"),
    WINDOW_MANAGEMENT("window-management"),
    WRITER("writer"),
    XR_SPATIAL_TRACKING("xr-spatial-tracking");

    private String value;

    PermissionsPolicyFeature(String value) {
        this.value = value;
    }

    public static PermissionsPolicyFeature fromString(String s) {
        return java.util.Arrays.stream(PermissionsPolicyFeature.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within PermissionsPolicyFeature "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static PermissionsPolicyFeature fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}
