package org.openqa.selenium.devtools.v149.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Maps to |SCARD_*| connection state values.
 */
public enum ConnectionState {

    ABSENT("absent"),
    PRESENT("present"),
    SWALLOWED("swallowed"),
    POWERED("powered"),
    NEGOTIABLE("negotiable"),
    SPECIFIC("specific");

    private String value;

    ConnectionState(String value) {
        this.value = value;
    }

    public static ConnectionState fromString(String s) {
        return java.util.Arrays.stream(ConnectionState.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within ConnectionState "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static ConnectionState fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}
