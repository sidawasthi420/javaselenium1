package org.openqa.selenium.devtools.v149.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class ReaderStateIn {

    private final java.lang.String reader;

    private final org.openqa.selenium.devtools.v149.smartcardemulation.model.ReaderStateFlags currentState;

    private final java.lang.Integer currentInsertionCount;

    public ReaderStateIn(java.lang.String reader, org.openqa.selenium.devtools.v149.smartcardemulation.model.ReaderStateFlags currentState, java.lang.Integer currentInsertionCount) {
        this.reader = java.util.Objects.requireNonNull(reader, "reader is required");
        this.currentState = java.util.Objects.requireNonNull(currentState, "currentState is required");
        this.currentInsertionCount = java.util.Objects.requireNonNull(currentInsertionCount, "currentInsertionCount is required");
    }

    public java.lang.String getReader() {
        return reader;
    }

    public org.openqa.selenium.devtools.v149.smartcardemulation.model.ReaderStateFlags getCurrentState() {
        return currentState;
    }

    public java.lang.Integer getCurrentInsertionCount() {
        return currentInsertionCount;
    }

    private static ReaderStateIn fromJson(JsonInput input) {
        java.lang.String reader = null;
        org.openqa.selenium.devtools.v149.smartcardemulation.model.ReaderStateFlags currentState = null;
        java.lang.Integer currentInsertionCount = 0;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "reader":
                    reader = input.nextString();
                    break;
                case "currentState":
                    currentState = input.read(org.openqa.selenium.devtools.v149.smartcardemulation.model.ReaderStateFlags.class);
                    break;
                case "currentInsertionCount":
                    currentInsertionCount = input.nextNumber().intValue();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ReaderStateIn(reader, currentState, currentInsertionCount);
    }
}
