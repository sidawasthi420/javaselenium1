package org.openqa.selenium.devtools.v149.webmcp;

import org.openqa.selenium.Beta;
import org.openqa.selenium.devtools.Command;
import org.openqa.selenium.devtools.Event;
import org.openqa.selenium.devtools.ConverterFunctions;
import java.util.Map;
import java.util.LinkedHashMap;
import org.openqa.selenium.json.JsonInput;

@Beta()
public class WebMCP {

    /**
     * Enables the WebMCP domain, allowing events to be sent. Enabling the domain will trigger a toolsAdded event for
     * all currently registered tools.
     */
    public static Command<Void> enable() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("WebMCP.enable", Map.copyOf(params));
    }

    /**
     * Disables the WebMCP domain.
     */
    public static Command<Void> disable() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("WebMCP.disable", Map.copyOf(params));
    }

    /**
     * Invokes a registered tool.
     */
    public static Command<java.lang.String> invokeTool(org.openqa.selenium.devtools.v149.page.model.FrameId frameId, java.lang.String toolName, java.util.Map<String, Object> input) {
        java.util.Objects.requireNonNull(frameId, "frameId is required");
        java.util.Objects.requireNonNull(toolName, "toolName is required");
        java.util.Objects.requireNonNull(input, "input is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("frameId", frameId);
        params.put("toolName", toolName);
        params.put("input", input);
        return new Command<>("WebMCP.invokeTool", Map.copyOf(params), ConverterFunctions.map("invocationId", java.lang.String.class));
    }

    /**
     * Cancels a pending tool invocation.
     */
    public static Command<Void> cancelInvocation(java.lang.String invocationId) {
        java.util.Objects.requireNonNull(invocationId, "invocationId is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("invocationId", invocationId);
        return new Command<>("WebMCP.cancelInvocation", Map.copyOf(params));
    }

    public static Event<java.util.List<org.openqa.selenium.devtools.v149.webmcp.model.Tool>> toolsAdded() {
        return new Event<>("WebMCP.toolsAdded", ConverterFunctions.map("tools", input -> input.readArray(org.openqa.selenium.devtools.v149.webmcp.model.Tool.class)));
    }

    public static Event<java.util.List<org.openqa.selenium.devtools.v149.webmcp.model.RemovedTool>> toolsRemoved() {
        return new Event<>("WebMCP.toolsRemoved", ConverterFunctions.map("tools", input -> input.readArray(org.openqa.selenium.devtools.v149.webmcp.model.RemovedTool.class)));
    }

    public static Event<org.openqa.selenium.devtools.v149.webmcp.model.ToolInvoked> toolInvoked() {
        return new Event<>("WebMCP.toolInvoked", input -> input.read(org.openqa.selenium.devtools.v149.webmcp.model.ToolInvoked.class));
    }

    public static Event<org.openqa.selenium.devtools.v149.webmcp.model.ToolResponded> toolResponded() {
        return new Event<>("WebMCP.toolResponded", input -> input.read(org.openqa.selenium.devtools.v149.webmcp.model.ToolResponded.class));
    }
}
