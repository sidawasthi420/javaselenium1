package org.openqa.selenium.devtools.v149.webmcp.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Tool annotations
 */
public class Annotation {

    private final java.util.Optional<java.lang.Boolean> readOnly;

    private final java.util.Optional<java.lang.Boolean> untrustedContent;

    private final java.util.Optional<java.lang.Boolean> autosubmit;

    public Annotation(java.util.Optional<java.lang.Boolean> readOnly, java.util.Optional<java.lang.Boolean> untrustedContent, java.util.Optional<java.lang.Boolean> autosubmit) {
        this.readOnly = readOnly;
        this.untrustedContent = untrustedContent;
        this.autosubmit = autosubmit;
    }

    /**
     * A hint indicating that the tool does not modify any state.
     */
    public java.util.Optional<java.lang.Boolean> getReadOnly() {
        return readOnly;
    }

    /**
     * A hint indicating that the tool output may contain untrusted content, ex: UGC, 3rd party data.
     */
    public java.util.Optional<java.lang.Boolean> getUntrustedContent() {
        return untrustedContent;
    }

    /**
     * If the declarative tool was declared with the autosubmit attribute.
     */
    public java.util.Optional<java.lang.Boolean> getAutosubmit() {
        return autosubmit;
    }

    private static Annotation fromJson(JsonInput input) {
        java.util.Optional<java.lang.Boolean> readOnly = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> untrustedContent = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> autosubmit = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "readOnly":
                    readOnly = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "untrustedContent":
                    untrustedContent = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "autosubmit":
                    autosubmit = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new Annotation(readOnly, untrustedContent, autosubmit);
    }
}
