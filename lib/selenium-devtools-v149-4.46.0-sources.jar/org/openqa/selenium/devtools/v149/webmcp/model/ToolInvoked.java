package org.openqa.selenium.devtools.v149.webmcp.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Event fired when a tool invocation starts.
 */
public class ToolInvoked {

    private final java.lang.String toolName;

    private final org.openqa.selenium.devtools.v149.page.model.FrameId frameId;

    private final java.lang.String invocationId;

    private final java.lang.String _input;

    public ToolInvoked(java.lang.String toolName, org.openqa.selenium.devtools.v149.page.model.FrameId frameId, java.lang.String invocationId, java.lang.String _input) {
        this.toolName = java.util.Objects.requireNonNull(toolName, "toolName is required");
        this.frameId = java.util.Objects.requireNonNull(frameId, "frameId is required");
        this.invocationId = java.util.Objects.requireNonNull(invocationId, "invocationId is required");
        this._input = java.util.Objects.requireNonNull(_input, "input is required");
    }

    /**
     * Name of the tool to invoke.
     */
    public java.lang.String getToolName() {
        return toolName;
    }

    /**
     * Frame id
     */
    public org.openqa.selenium.devtools.v149.page.model.FrameId getFrameId() {
        return frameId;
    }

    /**
     * Invocation identifier.
     */
    public java.lang.String getInvocationId() {
        return invocationId;
    }

    /**
     * The input parameters used for the invocation.
     */
    public java.lang.String getInput() {
        return _input;
    }

    private static ToolInvoked fromJson(JsonInput input) {
        java.lang.String toolName = null;
        org.openqa.selenium.devtools.v149.page.model.FrameId frameId = null;
        java.lang.String invocationId = null;
        java.lang.String _input = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "toolName":
                    toolName = input.nextString();
                    break;
                case "frameId":
                    frameId = input.read(org.openqa.selenium.devtools.v149.page.model.FrameId.class);
                    break;
                case "invocationId":
                    invocationId = input.nextString();
                    break;
                case "input":
                    _input = input.nextString();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ToolInvoked(toolName, frameId, invocationId, _input);
    }
}
