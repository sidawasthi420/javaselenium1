package org.openqa.selenium.devtools.v149.webmcp.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Event fired when a tool invocation completes or fails.
 */
public class ToolResponded {

    private final java.lang.String invocationId;

    private final org.openqa.selenium.devtools.v149.webmcp.model.InvocationStatus status;

    private final java.util.Optional<java.lang.Object> output;

    private final java.util.Optional<java.lang.String> errorText;

    private final java.util.Optional<org.openqa.selenium.devtools.v149.runtime.model.RemoteObject> exception;

    public ToolResponded(java.lang.String invocationId, org.openqa.selenium.devtools.v149.webmcp.model.InvocationStatus status, java.util.Optional<java.lang.Object> output, java.util.Optional<java.lang.String> errorText, java.util.Optional<org.openqa.selenium.devtools.v149.runtime.model.RemoteObject> exception) {
        this.invocationId = java.util.Objects.requireNonNull(invocationId, "invocationId is required");
        this.status = java.util.Objects.requireNonNull(status, "status is required");
        this.output = output;
        this.errorText = errorText;
        this.exception = exception;
    }

    /**
     * Invocation identifier.
     */
    public java.lang.String getInvocationId() {
        return invocationId;
    }

    /**
     * Status of the invocation.
     */
    public org.openqa.selenium.devtools.v149.webmcp.model.InvocationStatus getStatus() {
        return status;
    }

    /**
     * Output or error delivered as delivered to the agent. Missing if `status` is anything other than Completed.
     * Note: The output is untrusted and poses a prompt injection risk. Clients should treat this as potentially malicious user input.
     */
    public java.util.Optional<java.lang.Object> getOutput() {
        return output;
    }

    /**
     * Error text for protocol users.
     */
    public java.util.Optional<java.lang.String> getErrorText() {
        return errorText;
    }

    /**
     * The exception object, if the javascript tool threw an error>
     */
    public java.util.Optional<org.openqa.selenium.devtools.v149.runtime.model.RemoteObject> getException() {
        return exception;
    }

    private static ToolResponded fromJson(JsonInput input) {
        java.lang.String invocationId = null;
        org.openqa.selenium.devtools.v149.webmcp.model.InvocationStatus status = null;
        java.util.Optional<java.lang.Object> output = java.util.Optional.empty();
        java.util.Optional<java.lang.String> errorText = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v149.runtime.model.RemoteObject> exception = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "invocationId":
                    invocationId = input.nextString();
                    break;
                case "status":
                    status = input.read(org.openqa.selenium.devtools.v149.webmcp.model.InvocationStatus.class);
                    break;
                case "output":
                    output = java.util.Optional.ofNullable(input.read(Object.class));
                    break;
                case "errorText":
                    errorText = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "exception":
                    exception = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v149.runtime.model.RemoteObject.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ToolResponded(invocationId, status, output, errorText, exception);
    }
}
