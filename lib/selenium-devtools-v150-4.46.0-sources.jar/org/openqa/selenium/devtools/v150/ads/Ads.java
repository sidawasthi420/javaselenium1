package org.openqa.selenium.devtools.v150.ads;

import org.openqa.selenium.Beta;
import org.openqa.selenium.devtools.Command;
import org.openqa.selenium.devtools.Event;
import org.openqa.selenium.devtools.ConverterFunctions;
import java.util.Map;
import java.util.LinkedHashMap;
import org.openqa.selenium.json.JsonInput;

/**
 * A domain for ad-related metrics and data.
 */
@Beta()
public class Ads {

    /**
     * Retrieves ad metrics for the current page.
     */
    public static Command<org.openqa.selenium.devtools.v150.ads.model.AdMetrics> getAdMetrics() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Ads.getAdMetrics", Map.copyOf(params), ConverterFunctions.map("metrics", org.openqa.selenium.devtools.v150.ads.model.AdMetrics.class));
    }
}
