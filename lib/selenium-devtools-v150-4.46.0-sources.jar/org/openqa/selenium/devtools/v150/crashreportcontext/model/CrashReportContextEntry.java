package org.openqa.selenium.devtools.v150.crashreportcontext.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Key-value pair in CrashReportContext.
 */
public class CrashReportContextEntry {

    private final java.lang.String key;

    private final java.lang.String value;

    private final org.openqa.selenium.devtools.v150.page.model.FrameId frameId;

    public CrashReportContextEntry(java.lang.String key, java.lang.String value, org.openqa.selenium.devtools.v150.page.model.FrameId frameId) {
        this.key = java.util.Objects.requireNonNull(key, "key is required");
        this.value = java.util.Objects.requireNonNull(value, "value is required");
        this.frameId = java.util.Objects.requireNonNull(frameId, "frameId is required");
    }

    public java.lang.String getKey() {
        return key;
    }

    public java.lang.String getValue() {
        return value;
    }

    /**
     * The ID of the frame where the key-value pair was set.
     */
    public org.openqa.selenium.devtools.v150.page.model.FrameId getFrameId() {
        return frameId;
    }

    private static CrashReportContextEntry fromJson(JsonInput input) {
        java.lang.String key = null;
        java.lang.String value = null;
        org.openqa.selenium.devtools.v150.page.model.FrameId frameId = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "key":
                    key = input.nextString();
                    break;
                case "value":
                    value = input.nextString();
                    break;
                case "frameId":
                    frameId = input.read(org.openqa.selenium.devtools.v150.page.model.FrameId.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new CrashReportContextEntry(key, value, frameId);
    }
}
