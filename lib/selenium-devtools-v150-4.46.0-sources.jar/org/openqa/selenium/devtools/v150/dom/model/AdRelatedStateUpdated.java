package org.openqa.selenium.devtools.v150.dom.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when a node's ad related state changes.
 */
@org.openqa.selenium.Beta()
public class AdRelatedStateUpdated {

    private final org.openqa.selenium.devtools.v150.dom.model.NodeId nodeId;

    private final java.util.Optional<org.openqa.selenium.devtools.v150.network.model.AdProvenance> adProvenance;

    public AdRelatedStateUpdated(org.openqa.selenium.devtools.v150.dom.model.NodeId nodeId, java.util.Optional<org.openqa.selenium.devtools.v150.network.model.AdProvenance> adProvenance) {
        this.nodeId = java.util.Objects.requireNonNull(nodeId, "nodeId is required");
        this.adProvenance = adProvenance;
    }

    /**
     * The id of the node.
     */
    public org.openqa.selenium.devtools.v150.dom.model.NodeId getNodeId() {
        return nodeId;
    }

    /**
     * The provenance of the ad related node, if it is ad related.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v150.network.model.AdProvenance> getAdProvenance() {
        return adProvenance;
    }

    private static AdRelatedStateUpdated fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v150.dom.model.NodeId nodeId = null;
        java.util.Optional<org.openqa.selenium.devtools.v150.network.model.AdProvenance> adProvenance = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "nodeId":
                    nodeId = input.read(org.openqa.selenium.devtools.v150.dom.model.NodeId.class);
                    break;
                case "adProvenance":
                    adProvenance = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v150.network.model.AdProvenance.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AdRelatedStateUpdated(nodeId, adProvenance);
    }
}
