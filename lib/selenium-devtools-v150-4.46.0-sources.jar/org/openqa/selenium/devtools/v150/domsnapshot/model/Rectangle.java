package org.openqa.selenium.devtools.v150.domsnapshot.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class Rectangle {

    private final java.util.List<java.lang.Number> rectangle;

    public Rectangle(java.util.List<java.lang.Number> rectangle) {
        this.rectangle = java.util.Objects.requireNonNull(rectangle, "Missing value for Rectangle");
    }

    private static Rectangle fromJson(JsonInput input) {
        return new Rectangle(input.readArray(java.lang.Number.class));
    }

    public java.util.List<java.lang.Number> getRectangle() {
        return rectangle;
    }

    public String toString() {
        return rectangle.toString();
    }
}
