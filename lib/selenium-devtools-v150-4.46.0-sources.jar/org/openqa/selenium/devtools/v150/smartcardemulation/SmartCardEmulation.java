package org.openqa.selenium.devtools.v150.smartcardemulation;

import org.openqa.selenium.Beta;
import org.openqa.selenium.devtools.Command;
import org.openqa.selenium.devtools.Event;
import org.openqa.selenium.devtools.ConverterFunctions;
import java.util.Map;
import java.util.LinkedHashMap;
import org.openqa.selenium.json.JsonInput;

@Beta()
public class SmartCardEmulation {

    /**
     * Enables the |SmartCardEmulation| domain.
     */
    public static Command<Void> enable() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("SmartCardEmulation.enable", Map.copyOf(params));
    }

    /**
     * Disables the |SmartCardEmulation| domain.
     */
    public static Command<Void> disable() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("SmartCardEmulation.disable", Map.copyOf(params));
    }

    /**
     * Reports the successful result of a |SCardEstablishContext| call.
     *
     * This maps to:
     * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#gaa1b8970169fd4883a6dc4a8f43f19b67
     * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardestablishcontext
     */
    public static Command<Void> reportEstablishContextResult(java.lang.String requestId, java.lang.Integer contextId) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        java.util.Objects.requireNonNull(contextId, "contextId is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        params.put("contextId", contextId);
        return new Command<>("SmartCardEmulation.reportEstablishContextResult", Map.copyOf(params));
    }

    /**
     * Reports the successful result of a |SCardReleaseContext| call.
     *
     * This maps to:
     * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#ga6aabcba7744c5c9419fdd6404f73a934
     * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardreleasecontext
     */
    public static Command<Void> reportReleaseContextResult(java.lang.String requestId) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        return new Command<>("SmartCardEmulation.reportReleaseContextResult", Map.copyOf(params));
    }

    /**
     * Reports the successful result of a |SCardListReaders| call.
     *
     * This maps to:
     * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#ga93b07815789b3cf2629d439ecf20f0d9
     * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardlistreadersa
     */
    public static Command<Void> reportListReadersResult(java.lang.String requestId, java.util.List<java.lang.String> readers) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        java.util.Objects.requireNonNull(readers, "readers is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        params.put("readers", readers);
        return new Command<>("SmartCardEmulation.reportListReadersResult", Map.copyOf(params));
    }

    /**
     * Reports the successful result of a |SCardGetStatusChange| call.
     *
     * This maps to:
     * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#ga33247d5d1257d59e55647c3bb717db24
     * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardgetstatuschangea
     */
    public static Command<Void> reportGetStatusChangeResult(java.lang.String requestId, java.util.List<org.openqa.selenium.devtools.v150.smartcardemulation.model.ReaderStateOut> readerStates) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        java.util.Objects.requireNonNull(readerStates, "readerStates is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        params.put("readerStates", readerStates);
        return new Command<>("SmartCardEmulation.reportGetStatusChangeResult", Map.copyOf(params));
    }

    /**
     * Reports the result of a |SCardBeginTransaction| call.
     * On success, this creates a new transaction object.
     *
     * This maps to:
     * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#gaddb835dce01a0da1d6ca02d33ee7d861
     * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardbegintransaction
     */
    public static Command<Void> reportBeginTransactionResult(java.lang.String requestId, java.lang.Integer handle) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        java.util.Objects.requireNonNull(handle, "handle is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        params.put("handle", handle);
        return new Command<>("SmartCardEmulation.reportBeginTransactionResult", Map.copyOf(params));
    }

    /**
     * Reports the successful result of a call that returns only a result code.
     * Used for: |SCardCancel|, |SCardDisconnect|, |SCardSetAttrib|, |SCardEndTransaction|.
     *
     * This maps to:
     * 1. SCardCancel
     *    PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#gaacbbc0c6d6c0cbbeb4f4debf6fbeeee6
     *    Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardcancel
     *
     * 2. SCardDisconnect
     *    PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#ga4be198045c73ec0deb79e66c0ca1738a
     *    Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scarddisconnect
     *
     * 3. SCardSetAttrib
     *    PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#ga060f0038a4ddfd5dd2b8fadf3c3a2e4f
     *    Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardsetattrib
     *
     * 4. SCardEndTransaction
     *    PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#gae8742473b404363e5c587f570d7e2f3b
     *    Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardendtransaction
     */
    public static Command<Void> reportPlainResult(java.lang.String requestId) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        return new Command<>("SmartCardEmulation.reportPlainResult", Map.copyOf(params));
    }

    /**
     * Reports the successful result of a |SCardConnect| call.
     *
     * This maps to:
     * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#ga4e515829752e0a8dbc4d630696a8d6a5
     * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardconnecta
     */
    public static Command<Void> reportConnectResult(java.lang.String requestId, java.lang.Integer handle, java.util.Optional<org.openqa.selenium.devtools.v150.smartcardemulation.model.Protocol> activeProtocol) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        java.util.Objects.requireNonNull(handle, "handle is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        params.put("handle", handle);
        activeProtocol.ifPresent(p -> params.put("activeProtocol", p));
        return new Command<>("SmartCardEmulation.reportConnectResult", Map.copyOf(params));
    }

    /**
     * Reports the successful result of a call that sends back data on success.
     * Used for |SCardTransmit|, |SCardControl|, and |SCardGetAttrib|.
     *
     * This maps to:
     * 1. SCardTransmit
     *    PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#ga9a2d77242a271310269065e64633ab99
     *    Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardtransmit
     *
     * 2. SCardControl
     *    PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#gac3454d4657110fd7f753b2d3d8f4e32f
     *    Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardcontrol
     *
     * 3. SCardGetAttrib
     *    PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#gaacfec51917255b7a25b94c5104961602
     *    Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardgetattrib
     */
    public static Command<Void> reportDataResult(java.lang.String requestId, java.lang.String data) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        java.util.Objects.requireNonNull(data, "data is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        params.put("data", data);
        return new Command<>("SmartCardEmulation.reportDataResult", Map.copyOf(params));
    }

    /**
     * Reports the successful result of a |SCardStatus| call.
     *
     * This maps to:
     * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#gae49c3c894ad7ac12a5b896bde70d0382
     * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardstatusa
     */
    public static Command<Void> reportStatusResult(java.lang.String requestId, java.lang.String readerName, org.openqa.selenium.devtools.v150.smartcardemulation.model.ConnectionState state, java.lang.String atr, java.util.Optional<org.openqa.selenium.devtools.v150.smartcardemulation.model.Protocol> protocol) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        java.util.Objects.requireNonNull(readerName, "readerName is required");
        java.util.Objects.requireNonNull(state, "state is required");
        java.util.Objects.requireNonNull(atr, "atr is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        params.put("readerName", readerName);
        params.put("state", state);
        params.put("atr", atr);
        protocol.ifPresent(p -> params.put("protocol", p));
        return new Command<>("SmartCardEmulation.reportStatusResult", Map.copyOf(params));
    }

    /**
     * Reports an error result for the given request.
     */
    public static Command<Void> reportError(java.lang.String requestId, org.openqa.selenium.devtools.v150.smartcardemulation.model.ResultCode resultCode) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        java.util.Objects.requireNonNull(resultCode, "resultCode is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        params.put("resultCode", resultCode);
        return new Command<>("SmartCardEmulation.reportError", Map.copyOf(params));
    }

    public static Event<java.lang.String> establishContextRequested() {
        return new Event<>("SmartCardEmulation.establishContextRequested", ConverterFunctions.map("requestId", java.lang.String.class));
    }

    public static Event<org.openqa.selenium.devtools.v150.smartcardemulation.model.ReleaseContextRequested> releaseContextRequested() {
        return new Event<>("SmartCardEmulation.releaseContextRequested", input -> input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.ReleaseContextRequested.class));
    }

    public static Event<org.openqa.selenium.devtools.v150.smartcardemulation.model.ListReadersRequested> listReadersRequested() {
        return new Event<>("SmartCardEmulation.listReadersRequested", input -> input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.ListReadersRequested.class));
    }

    public static Event<org.openqa.selenium.devtools.v150.smartcardemulation.model.GetStatusChangeRequested> getStatusChangeRequested() {
        return new Event<>("SmartCardEmulation.getStatusChangeRequested", input -> input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.GetStatusChangeRequested.class));
    }

    public static Event<org.openqa.selenium.devtools.v150.smartcardemulation.model.CancelRequested> cancelRequested() {
        return new Event<>("SmartCardEmulation.cancelRequested", input -> input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.CancelRequested.class));
    }

    public static Event<org.openqa.selenium.devtools.v150.smartcardemulation.model.ConnectRequested> connectRequested() {
        return new Event<>("SmartCardEmulation.connectRequested", input -> input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.ConnectRequested.class));
    }

    public static Event<org.openqa.selenium.devtools.v150.smartcardemulation.model.DisconnectRequested> disconnectRequested() {
        return new Event<>("SmartCardEmulation.disconnectRequested", input -> input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.DisconnectRequested.class));
    }

    public static Event<org.openqa.selenium.devtools.v150.smartcardemulation.model.TransmitRequested> transmitRequested() {
        return new Event<>("SmartCardEmulation.transmitRequested", input -> input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.TransmitRequested.class));
    }

    public static Event<org.openqa.selenium.devtools.v150.smartcardemulation.model.ControlRequested> controlRequested() {
        return new Event<>("SmartCardEmulation.controlRequested", input -> input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.ControlRequested.class));
    }

    public static Event<org.openqa.selenium.devtools.v150.smartcardemulation.model.GetAttribRequested> getAttribRequested() {
        return new Event<>("SmartCardEmulation.getAttribRequested", input -> input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.GetAttribRequested.class));
    }

    public static Event<org.openqa.selenium.devtools.v150.smartcardemulation.model.SetAttribRequested> setAttribRequested() {
        return new Event<>("SmartCardEmulation.setAttribRequested", input -> input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.SetAttribRequested.class));
    }

    public static Event<org.openqa.selenium.devtools.v150.smartcardemulation.model.StatusRequested> statusRequested() {
        return new Event<>("SmartCardEmulation.statusRequested", input -> input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.StatusRequested.class));
    }

    public static Event<org.openqa.selenium.devtools.v150.smartcardemulation.model.BeginTransactionRequested> beginTransactionRequested() {
        return new Event<>("SmartCardEmulation.beginTransactionRequested", input -> input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.BeginTransactionRequested.class));
    }

    public static Event<org.openqa.selenium.devtools.v150.smartcardemulation.model.EndTransactionRequested> endTransactionRequested() {
        return new Event<>("SmartCardEmulation.endTransactionRequested", input -> input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.EndTransactionRequested.class));
    }
}
