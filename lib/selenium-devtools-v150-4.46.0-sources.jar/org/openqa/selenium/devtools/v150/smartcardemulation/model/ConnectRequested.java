package org.openqa.selenium.devtools.v150.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when |SCardConnect| is called.
 *
 * This maps to:
 * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#ga4e515829752e0a8dbc4d630696a8d6a5
 * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardconnecta
 */
public class ConnectRequested {

    private final java.lang.String requestId;

    private final java.lang.Integer contextId;

    private final java.lang.String reader;

    private final org.openqa.selenium.devtools.v150.smartcardemulation.model.ShareMode shareMode;

    private final org.openqa.selenium.devtools.v150.smartcardemulation.model.ProtocolSet preferredProtocols;

    public ConnectRequested(java.lang.String requestId, java.lang.Integer contextId, java.lang.String reader, org.openqa.selenium.devtools.v150.smartcardemulation.model.ShareMode shareMode, org.openqa.selenium.devtools.v150.smartcardemulation.model.ProtocolSet preferredProtocols) {
        this.requestId = java.util.Objects.requireNonNull(requestId, "requestId is required");
        this.contextId = java.util.Objects.requireNonNull(contextId, "contextId is required");
        this.reader = java.util.Objects.requireNonNull(reader, "reader is required");
        this.shareMode = java.util.Objects.requireNonNull(shareMode, "shareMode is required");
        this.preferredProtocols = java.util.Objects.requireNonNull(preferredProtocols, "preferredProtocols is required");
    }

    public java.lang.String getRequestId() {
        return requestId;
    }

    public java.lang.Integer getContextId() {
        return contextId;
    }

    public java.lang.String getReader() {
        return reader;
    }

    public org.openqa.selenium.devtools.v150.smartcardemulation.model.ShareMode getShareMode() {
        return shareMode;
    }

    public org.openqa.selenium.devtools.v150.smartcardemulation.model.ProtocolSet getPreferredProtocols() {
        return preferredProtocols;
    }

    private static ConnectRequested fromJson(JsonInput input) {
        java.lang.String requestId = null;
        java.lang.Integer contextId = 0;
        java.lang.String reader = null;
        org.openqa.selenium.devtools.v150.smartcardemulation.model.ShareMode shareMode = null;
        org.openqa.selenium.devtools.v150.smartcardemulation.model.ProtocolSet preferredProtocols = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "requestId":
                    requestId = input.nextString();
                    break;
                case "contextId":
                    contextId = input.nextNumber().intValue();
                    break;
                case "reader":
                    reader = input.nextString();
                    break;
                case "shareMode":
                    shareMode = input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.ShareMode.class);
                    break;
                case "preferredProtocols":
                    preferredProtocols = input.read(org.openqa.selenium.devtools.v150.smartcardemulation.model.ProtocolSet.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ConnectRequested(requestId, contextId, reader, shareMode, preferredProtocols);
    }
}
