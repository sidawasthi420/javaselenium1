package org.openqa.selenium.devtools.v150.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when |SCardReleaseContext| is called.
 *
 * This maps to:
 * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#ga6aabcba7744c5c9419fdd6404f73a934
 * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardreleasecontext
 */
public class ReleaseContextRequested {

    private final java.lang.String requestId;

    private final java.lang.Integer contextId;

    public ReleaseContextRequested(java.lang.String requestId, java.lang.Integer contextId) {
        this.requestId = java.util.Objects.requireNonNull(requestId, "requestId is required");
        this.contextId = java.util.Objects.requireNonNull(contextId, "contextId is required");
    }

    public java.lang.String getRequestId() {
        return requestId;
    }

    public java.lang.Integer getContextId() {
        return contextId;
    }

    private static ReleaseContextRequested fromJson(JsonInput input) {
        java.lang.String requestId = null;
        java.lang.Integer contextId = 0;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "requestId":
                    requestId = input.nextString();
                    break;
                case "contextId":
                    contextId = input.nextNumber().intValue();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ReleaseContextRequested(requestId, contextId);
    }
}
