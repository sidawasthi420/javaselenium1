package org.openqa.selenium.devtools.v150.smartcardemulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Fired when |SCardSetAttrib| is called.
 *
 * This maps to:
 * PC/SC Lite: https://pcsclite.apdu.fr/api/group__API.html#ga060f0038a4ddfd5dd2b8fadf3c3a2e4f
 * Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winscard/nf-winscard-scardsetattrib
 */
public class SetAttribRequested {

    private final java.lang.String requestId;

    private final java.lang.Integer handle;

    private final java.lang.Integer attribId;

    private final java.lang.String data;

    public SetAttribRequested(java.lang.String requestId, java.lang.Integer handle, java.lang.Integer attribId, java.lang.String data) {
        this.requestId = java.util.Objects.requireNonNull(requestId, "requestId is required");
        this.handle = java.util.Objects.requireNonNull(handle, "handle is required");
        this.attribId = java.util.Objects.requireNonNull(attribId, "attribId is required");
        this.data = java.util.Objects.requireNonNull(data, "data is required");
    }

    public java.lang.String getRequestId() {
        return requestId;
    }

    public java.lang.Integer getHandle() {
        return handle;
    }

    public java.lang.Integer getAttribId() {
        return attribId;
    }

    public java.lang.String getData() {
        return data;
    }

    private static SetAttribRequested fromJson(JsonInput input) {
        java.lang.String requestId = null;
        java.lang.Integer handle = 0;
        java.lang.Integer attribId = 0;
        java.lang.String data = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "requestId":
                    requestId = input.nextString();
                    break;
                case "handle":
                    handle = input.nextNumber().intValue();
                    break;
                case "attribId":
                    attribId = input.nextNumber().intValue();
                    break;
                case "data":
                    data = input.nextString();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new SetAttribRequested(requestId, handle, attribId, data);
    }
}
